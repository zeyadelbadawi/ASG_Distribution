'use client';
import Layout from "@/components/layout/Layout"


export default function Home() {

    return (
        <>
            <div className="homestyle2">
                <Layout headerStyle={2} footerStyle={2}>
             
                </Layout>
            </div>
        </>
    )
}
